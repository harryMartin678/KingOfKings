# jhlabs filters

Clone of jhlabs filters library.

Unfortunately original upload to Maven Cetral Repo has missing filters. And I unable to find / contact the person who made the first upload.
After contacting sonatype.org, we have decided to re-upload the source with new version prefix.

Filters are missing in the original Central Maven Deploy:
  * com.jhlabs.filters.images.DoGFilter
  * com.jhlabs.filters.images.LaplaceFilter

## Original links

  * http://www.jhlabs.com/ip/index.html
  * http://www.jhlabs.com/ip/filters/index.html

## Licence

http://www.jhlabs.com/ip/filters/download.html

Licensed under the Apache License, Version 2.0 (the "License"); you may not use this code except in compliance with the
License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 Unless required by
applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language
governing permissions and limitations under the License.

## Central Maven

     <dependency>
       <groupId>com.jhlabs</groupId>
       <artifactId>filters</artifactId>
       <version>2.0.235-1</version>
     </dependency>

## Links

  * https://issues.sonatype.org/browse/OSSRH-4718